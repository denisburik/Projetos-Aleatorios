﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes.modelo.Modelo
{
    public class Resumo:placaVeiculo
    {
        //public string PlacaVeiculo{ get; set; }
        public string Descricao { get; set; }
        public int Acentos { get; set; }
        public string Imagem { get; set; }
        public string Cor { get; set; }
    }
}
