﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classes.modelo.Modelo
{
    public class Registro:placaVeiculo
    {
        public string NomeCliente { get; set; }
        //public string placaVeic { get; set; }
        public DateTime data { get; set; }
        public double valorPag { get; set; }
    }
}
