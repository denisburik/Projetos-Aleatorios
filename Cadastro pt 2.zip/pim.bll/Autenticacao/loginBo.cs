﻿using pim.cad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pim.bll.Exceptions;
using classes.modelo;

namespace pim.bll.Autenticacao
{
    public class LoginBo
    {
        private UsuarioDao _usuarioDao;
        public Usuario Usuariolog(string login, string senha)
        {
            _usuarioDao = new UsuarioDao();

            var usuario =  _usuarioDao.ObterUsuarioeSenha(login, senha);

            if(usuario == null)
            {
                throw new Usuarionaocad();
            }
            else
            {
                return usuario;
            }
        }
    }
}
