﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pim.bll.Exceptions
{
    public class Usuarionaocad:Exception
    {
        public Usuarionaocad()
        {

        }

        public Usuarionaocad(string message)
        : base(message)
        {

        }

        public Usuarionaocad(string message, Exception inner)
        : base(message, inner)
        {

        }
    }
}
