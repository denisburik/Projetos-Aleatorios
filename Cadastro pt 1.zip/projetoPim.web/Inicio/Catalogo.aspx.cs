﻿using classes.modelo.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projetoPim.web.Inicio
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            carregarVeiculos();
        }
        private void carregarVeiculos()
        {
            RepeaterVeiculos.DataSource = new List<Veiculos>
            {
                new Veiculos {Nome = "Carro 1 " },
                new Veiculos {Nome = "Carro 2 " },
                new Veiculos {Nome = "Carro 3 " },
                new Veiculos {Nome = "Carro 4 " },
                new Veiculos {Nome = "Carro 5 " }
            };
            RepeaterVeiculos.DataBind();
        }
    }
}