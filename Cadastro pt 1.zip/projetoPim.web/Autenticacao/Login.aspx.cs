﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using pim.bll.Autenticacao;
using pim.bll.Exceptions;
using System.Web.Security;

namespace projetoPim.web.Autenticacao
{
    public partial class Login : System.Web.UI.Page
    {
        private LoginBo _loginBO;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            _loginBO = new LoginBo();

            var login = TxtUsuario.Text;
            var senha = TextBox2.Text;

            //LblStatus.
            try
            {
                var useruario = _loginBO.Usuariolog(login, senha);
                FormsAuthentication.RedirectFromLoginPage(login, false);
                LblStatus.Text = "Logado Com Sucesso";
                
            }
            catch (Usuarionaocad)
            {
                LblStatus.Text = "Usuario Não Cadastrado";
            }
            catch (Exception)
            {
                LblStatus.Text = "Ocorreu Um Erro Inesperado, Favor Consultar o Administrador do Sistema";
            }
        }
    }
}