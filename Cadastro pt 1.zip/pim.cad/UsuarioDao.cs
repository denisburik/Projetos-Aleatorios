﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using classes.modelo;
using System.Data.SqlClient;

namespace pim.cad
{
    public class UsuarioDao
    {
        public Usuario ObterUsuarioeSenha(string login, string senha)
        {
            try
            {
                Conexao.Conectar();

                var cmd = new SqlCommand();
                cmd.Connection = Conexao.con;
                cmd.CommandText = "SELECT * FROM tbUsuarios WHERE Usuario = @Usuario AND Senha = @Senha";

                cmd.Parameters.AddWithValue("@USUARIO", login);
                cmd.Parameters.AddWithValue("@SENHA", senha);                

                var read = cmd.ExecuteReader();
                Usuario user = null;

                while (read.Read())
                {
                    user = new Usuario();

                    user.id = Convert.ToInt32(read["id"]);
                    user.login = read["Usuario"].ToString();
                    user.senha = read["Senha"].ToString();
                    user.perfil = Convert.ToChar(read["Perfil"]);
                }
                return user;
            }
            catch (Exception e)
            {
                
                throw;
            }
            finally
            {
                Conexao.Desconectar();
            }
        }
    }
}
